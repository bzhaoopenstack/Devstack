---
layout: pose
title: OpenStack Glance-创建镜像V1
date: 2017-09-07 15:19:24
tags:
  - OpenStack
  - Glance
categories: OpenStack
---
创建镜像V1接口详解。
<!-- more -->
![glance](/images/OpenStack--Glance3.png)
