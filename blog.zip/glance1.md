---
layout: pose
title: OpenStack Glance-架构
date: 2017-09-07 15:19:24
tags: 
  - OpenStack
  - Glance
categories: OpenStack
---
本文介绍Glance的整体架构。
<!-- more -->
![glance](/images/OpenStack--Glance1.png)
