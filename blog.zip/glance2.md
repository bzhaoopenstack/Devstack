---
layout: pose
title: OpenStack Glance-task介绍
date: 2017-09-07 15:19:24
tags:
  - OpenStack
  - Glance
categories: OpenStack
---
Task接口概述。
<!-- more -->
![glance](/images/OpenStack--Glance2.png)
