---
title: About Me
date: 2017-09-07 16:17:10
comments: false
---
IRC Name: wxy

BackGround：OpenStacker、Upstream contributer。

Title:      Software Developer、Zaqar core reviewer、OpenStack and Kubernetes learner。

Skill：

- Zaqar: ★★★★
- Glance: ★★★☆
- Cinder: ★★★☆
- Keystone: ★★★ (Focusing on)
- Nova: ★
- Neutron: ☆
- Python: ★★★
- Golang: ☆
- Kubernetes: ★☆

