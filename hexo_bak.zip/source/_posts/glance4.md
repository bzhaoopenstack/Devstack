---
layout: pose
title: OpenStack Glance-创建镜像V2
date: 2017-09-07 15:19:24
tags:
  - OpenStack
  - Glance
categories: OpenStack
---
创建镜像V2接口详解。
<!-- more -->
![glance](/images/OpenStack--Glance4.png)
